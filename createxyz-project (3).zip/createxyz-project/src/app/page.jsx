"use client";
import React from "react";

function MainComponent() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 to-purple-100 p-8">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-800 transform hover:scale-105 transition-transform duration-300 ease-in-out shadow-lg p-4 bg-white rounded-lg inline-block">
            John Doe
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mt-4 transform hover:-translate-y-1 transition-transform duration-300 ease-in-out shadow-md p-2 bg-white rounded-md inline-block">
            Web Developer & Designer
          </p>
        </header>

        <section className="bg-white rounded-lg shadow-lg p-8 mb-12 transform hover:-rotate-1 transition-transform duration-300 ease-in-out relative">
          <div className="absolute inset-0 bg-gray-100 rounded-lg -z-10 transform rotate-2"></div>
          <h2 className="text-3xl font-semibold text-gray-800 mb-4">
            About Me
          </h2>
          <p className="text-gray-600">
            Hi there! I'm a passionate web developer and designer with a keen
            eye for creating beautiful and functional websites. I love bringing
            ideas to life through code and creativity.
          </p>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white rounded-lg shadow-lg p-6 transform hover:translate-y-[-4px] hover:translate-x-[2px] transition-transform duration-300 ease-in-out relative">
            <div className="absolute inset-0 bg-blue-50 rounded-lg -z-10 transform -rotate-1"></div>
            <h3 className="text-2xl font-semibold text-gray-800 mb-4">
              Skills
            </h3>
            <ul className="text-gray-600 space-y-2">
              <li className="flex items-center">
                <i className="fas fa-code mr-2 text-blue-500"></i>
                HTML, CSS, JavaScript
              </li>
              <li className="flex items-center">
                <i className="fab fa-react mr-2 text-blue-500"></i>
                React
              </li>
              <li className="flex items-center">
                <i className="fas fa-paint-brush mr-2 text-blue-500"></i>
                UI/UX Design
              </li>
            </ul>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6 transform hover:translate-y-[-4px] hover:translate-x-[2px] transition-transform duration-300 ease-in-out relative">
            <div className="absolute inset-0 bg-green-50 rounded-lg -z-10 transform rotate-1"></div>
            <h3 className="text-2xl font-semibold text-gray-800 mb-4">
              Projects
            </h3>
            <ul className="text-gray-600 space-y-2">
              <li className="flex items-center">
                <i className="fas fa-globe mr-2 text-green-500"></i>
                Personal Blog
              </li>
              <li className="flex items-center">
                <i className="fas fa-shopping-cart mr-2 text-green-500"></i>
                E-commerce Site
              </li>
              <li className="flex items-center">
                <i className="fas fa-mobile-alt mr-2 text-green-500"></i>
                Weather App
              </li>
            </ul>
          </div>
        </section>

        <footer className="text-center text-gray-600">
          <p className="mb-4">Let's connect!</p>
          <div className="flex justify-center space-x-4">
            <a
              href="#"
              className="text-2xl text-gray-800 hover:text-blue-500 transform hover:scale-110 transition-transform duration-300 ease-in-out"
            >
              <i className="fab fa-github"></i>
            </a>
            <a
              href="#"
              className="text-2xl text-gray-800 hover:text-blue-500 transform hover:scale-110 transition-transform duration-300 ease-in-out"
            >
              <i className="fab fa-linkedin"></i>
            </a>
            <a
              href="#"
              className="text-2xl text-gray-800 hover:text-blue-500 transform hover:scale-110 transition-transform duration-300 ease-in-out"
            >
              <i className="fab fa-twitter"></i>
            </a>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default MainComponent;